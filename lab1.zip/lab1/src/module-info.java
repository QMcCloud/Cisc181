/**
 * 
 */
/**
 * @author mccloud
 *
 */
module lab1 {
}